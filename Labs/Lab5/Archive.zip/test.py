# _*_coding: utf-8_*_

a = [[1, 2, 3], [2, 3, 4], [2, 3, 5]]

# for i in range(len(a[0])):
#     a[i].remove(a[i][2])
#
# a.remove(a[2])
print(a)
a.index([1,2,3])
print(a.index([1,2,3]))